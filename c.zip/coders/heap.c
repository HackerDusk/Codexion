# include "codexion.h"

int cmp_fifo(t_coder *cd_a, t_coder *cd_b)
{
    return (cd_a->request_time < cd_b->request_time);
}

int cmp_edf(t_coder *cd_a, t_coder *cd_b)
{
    return((cd_a->last_compile_start +
        cd_a->time_to_burnout) < (
        cd_b->last_compile_start +
        cd_b->time_to_burnout));
}

void    heap_push(t_heap *heap, t_coder *coder)
{
    size_t  i;
    size_t  parent;
    t_coder *tmp;

    if (heap->size >= heap->capacity)
        return;
    i = heap->size;
    heap->size++;
    heap->arr[i] = coder;
    while (i > 0)
    {
        parent = (i - 1) / 2;
        if (
            heap->cmp(heap->arr[i],
            heap->arr[parent]))
            {
                tmp = heap->arr[i];
                heap->arr[i] = heap->arr[parent];
                heap->arr[parent] = tmp;
                i = parent;
            }
        else
            break;
    }
}

t_coder *heap_pop(t_heap *heap)
{
    t_coder *res;
    t_coder *tmp;
    size_t  left;
    size_t  right;
    size_t  i;
    size_t  smallest;

    if (heap->size == 0)
        return (NULL);
    res = heap->arr[0];
    heap->arr[0] = heap->arr[heap->size - 1];
    heap->size--;
    i = 0;
    while (2 * i + 1 < heap->size)
    {
        left = 2 * i + 1;
        right = 2 * i + 2;
        smallest = left;
        if (right < heap->size && heap->cmp(heap->arr[right], heap->arr[left]))
            smallest = right;
        if (heap->cmp(heap->arr[smallest], heap->arr[i]))
        {
            tmp = heap->arr[smallest];
            heap->arr[smallest] = heap->arr[i];
            heap->arr[i] = tmp;
            i = smallest;
        }
        else
            break;
    }
    return res;
}