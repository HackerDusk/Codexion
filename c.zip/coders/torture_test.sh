#!/bin/bash

# ==============================================================================
# CONFIGURATION
# ==============================================================================
BIN="./codexion" # Remplace par le nom de ton exécutable si différent
TIMEOUT_SEC=10   # Temps maximum avant de considérer qu'il y a un deadlock

# Couleurs pour le drame
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
PURPLE='\033[1;35m'
CYAN='\033[1;36m'
NC='\033[0m'

echo -e "${PURPLE}=== DÉMARRAGE DU PROTOCOLE DE TORTURE ===${NC}\n"

if [ ! -f "$BIN" ]; then
    echo -e "${RED}[ERREUR] Exécutable $BIN introuvable. Compile d'abord avec -g3 !${NC}"
    exit 1
fi

# ==============================================================================
# FONCTIONS DE TEST
# ==============================================================================

run_test() {
    local test_name="$1"
    shift
    local args="$@"
    
    echo -e "${CYAN}[TEST] ${test_name}${NC} -> Args: [${args}]"
    timeout $TIMEOUT_SEC $BIN $args > /dev/null 2>&1
    local status=$?
    
    if [ $status -eq 124 ]; then
        echo -e "${RED} ↳ [DEADLOCK] Le programme a freeze (Timeout ${TIMEOUT_SEC}s).${NC}"
    elif [ $status -eq 139 ]; then
        echo -e "${RED} ↳ [SEGFAULT] Ton programme a crashé.${NC}"
    else
        echo -e "${GREEN} ↳ [SURVIE] Le programme a terminé sans crash (Exit: $status).${NC}"
    fi
}

run_valgrind() {
    local test_name="$1"
    shift
    local args="$@"
    
    echo -e "${YELLOW}[MEMCHECK] ${test_name}${NC}"
    valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --error-exitcode=42 $BIN $args > /dev/null 2>&1
    local status=$?
    
    if [ $status -eq 42 ]; then
        echo -e "${RED} ↳ [FUITE/ERREUR MÉMOIRE] Valgrind a trouvé du sang. Vérifie tes mallocs/free dans ta structure de heap.${NC}"
    else
        echo -e "${GREEN} ↳ [CLEAN] Aucune fuite détectée.${NC}"
    fi
}

run_helgrind() {
    local test_name="$1"
    shift
    local args="$@"
    
    echo -e "${PURPLE}[HELGRIND] ${test_name}${NC}"
    valgrind --tool=helgrind --history-level=approx --error-exitcode=42 $BIN $args > /dev/null 2>&1
    local status=$?
    
    if [ $status -eq 42 ]; then
        echo -e "${RED} ↳ [DATA RACE / DEADLOCK] Helgrind a paniqué. Vérifie tes mutexes et tes condition variables (wait/signal).${NC}"
    else
        echo -e "${GREEN} ↳ [THREAD SAFE] Synchronisation parfaite.${NC}"
    fi
}

# ==============================================================================
# PHASE 1 : TESTS "HUMAINS" (L'utilisateur qui ne sait pas lire)
# ==============================================================================
echo -e "\n${CYAN}--- PHASE 1 : ARGUMENT CHECKER (Humain) ---${NC}"
run_test "Pas d'arguments" 
run_test "Lettres au lieu de chiffres" "5" "dix" "15" "lol"
run_test "Arguments vides" "5" "" "10"
run_test "Espaces dans l'argument" " 5 " "10" "15"
run_test "Zéro absolu" "0" "0" "0" "0"
run_test "Nombres négatifs" "-5" "10" "15"

# ==============================================================================
# PHASE 2 : TESTS "HACKER" (L'utilisateur malveillant)
# ==============================================================================
echo -e "\n${YELLOW}--- PHASE 2 : DEBORDEMENTS & INJECTIONS (Hacker) ---${NC}"
run_test "INT_MAX dépassement" "2147483648" "10" "10"
run_test "INT_MIN" "-2147483648" "10" "10"
run_test "Float déguisé" "5.5" "10" "15"
run_test "Chaine interminable (Buffer Overflow)" "$(printf '9%.0s' {1..1000})" "10" "10"
run_test "Caractères non-imprimables" "5" "$(echo -e '\x07')" "10"

# ==============================================================================
# PHASE 3 : TESTS "EXAGÉRÉS" (Le stress test Helgrind / Valgrind)
# ==============================================================================
echo -e "\n${PURPLE}--- PHASE 3 : SYNCHRONISATION (L'Exagération Helgrind) ---${NC}"
# On suppose ici des arguments valides standards pour ton projet. 
# Modifie "5 800 200 200" par des arguments qui font tourner ton programme normalement.
VALID_ARGS="5 800 200 200" 

run_valgrind "Test Valgrind standard" $VALID_ARGS
run_helgrind "Test Helgrind standard" $VALID_ARGS

echo -e "${PURPLE}[SPAM HELGRIND] Lancement du même test 50 fois pour trouver LA data race de 1%...${NC}"
SUCCESS_COUNT=0
for i in {1..50}; do
    valgrind --tool=helgrind --error-exitcode=42 $BIN $VALID_ARGS > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        ((SUCCESS_COUNT++))
    else
        echo -e "${RED} ↳ Échec à l'itération $i !${NC}"
        break
    fi
done
if [ $SUCCESS_COUNT -eq 50 ]; then
    echo -e "${GREEN} ↳ 50/50 réussis. Tes mutexes sont en béton armé.${NC}"
fi

# ==============================================================================
# PHASE 4 : LE BURNOUT (Famine et épuisement des ressources)
# ==============================================================================
echo -e "\n${RED}--- PHASE 4 : LE BURNOUT TOTAL ---${NC}"

echo -e "${YELLOW}[BURNOUT] Création d'une armée de threads (1000+). pthread_create va-t-il survivre ?${NC}"
# Test avec un nombre absurde de "coders" ou de threads
run_test "L'Armée" "10000" "800" "200" "200"

echo -e "${YELLOW}[BURNOUT] Limitation de la RAM (ulimit) pour forcer l'échec de malloc().${NC}"
# On limite la mémoire virtuelle à ~10MB. Ton heap ou ton scheduler devrait échouer gracieusement sans leaker.
(
    ulimit -v 10000
    valgrind --leak-check=full --error-exitcode=42 $BIN 500 800 200 > /dev/null 2>&1
    if [ $? -eq 42 ]; then
         echo -e "${RED} ↳ [FAIL] Malloc a échoué, mais tu as leaké la mémoire déjà allouée avant le crash !${NC}"
    else
         echo -e "${GREEN} ↳ [PASS] Le programme a géré le manque de RAM sans leaker.${NC}"
    fi
)

echo -e "\n${PURPLE}=== FIN DU PROTOCOLE. VA RÉPARER TES SEGFAULTS. ===${NC}"