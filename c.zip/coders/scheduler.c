# include "codexion.h"

t_coder *get_next_coder(t_monitor *monitor)
{
    t_coder *next;

    next = heap_pop(monitor->heap);
    if (!next)
        return (NULL);
    next->is_my_turn = 1;
    pthread_cond_broadcast(&next->turn_cond);
    return (next);
}

void    *scheduler_routine(void *arg)
{
    t_monitor   *monitor;

    monitor = (t_monitor *)arg;
    while(!is_stopped(monitor))
    {
        pthread_mutex_lock(&monitor->scheduler_mutex);
        while (!monitor->heap->size && !is_stopped(monitor))
            pthread_cond_wait(&monitor->scheduler_cond, &monitor->scheduler_mutex);
        if (is_stopped(monitor))
        {
            pthread_mutex_unlock(&monitor->scheduler_mutex);
            break;
        }
        get_next_coder(monitor);
        pthread_mutex_unlock(&monitor->scheduler_mutex);
    }
    return (NULL);
}