/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   codexion.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mandresy <mandresy@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/08/25 17:04:13 by srandro           #+#    #+#             */
/*   Updated: 2026/09/03 22:07:50 by mandresy         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CODEXION_H
# define CODEXION_H

# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <string.h>
# include <pthread.h>
# include <limits.h>
# include <sys/time.h>
# include <errno.h>
# include <stddef.h>

typedef struct s_dongle
{
	int				id;
	int				dongle_cooldown;
	int				is_free;
	pthread_mutex_t	mutex;
	pthread_cond_t	dongle_cond;
	long long		available_at;
	
}	t_dongle;

typedef struct s_monitor	t_monitor;

typedef struct s_coder
{
	pthread_t		thread;
	pthread_cond_t	turn_cond;
	t_dongle		*left_dongle;
	t_dongle		*right_dongle;
	t_monitor		*monitor;
	int				is_my_turn;
	int				id;
	int				time_to_burnout;
	int				time_to_compile;
	int				time_to_debug;
	int				time_to_refactor;
	int				number_of_compiles_required;
	int				compiles_done;
	long long		last_compile_start;
	long long		request_time;
}	t_coder;

typedef struct s_heap
{
	t_coder		**arr;
	size_t		size;
	size_t		capacity;
	int			(*cmp)(t_coder *, t_coder *);
}	t_heap;

typedef struct s_monitor
{
	pthread_t			monitor_thread;
	pthread_t			scheduler_thread;
	pthread_mutex_t		monitor_mutex;
	pthread_mutex_t		print_mutex;
	pthread_mutex_t		scheduler_mutex;
	pthread_mutex_t		stop_mutex;
	pthread_cond_t		monitor_cond;
	pthread_cond_t		scheduler_cond;
	t_dongle			*dongles;
	t_coder				*coders;
	t_heap				*heap;
	int					nb_coders;
	char				*scheduler_type;
	int					stop_simulation;
	long long			start_time;
}	t_monitor;

int			full_arg_checker(int argc, char **argv);
t_monitor	*monitor_initializer(char **argv);
void		heap_push(t_heap *heap, t_coder *coder);
t_coder		*heap_pop(t_heap *heap);
int			cmp_fifo(t_coder *cd_a, t_coder *cd_b);
int			cmp_edf(t_coder *cd_a, t_coder *cd_b);
long long   get_time_ms(void);
void		ms_to_timespec(long long time_in_ms, struct timespec *ts);
int			take_a_dongle(t_coder *coder, struct timespec ts);
void		release_dongles(t_coder *coder);
void		*coder_routine(void *arg);
void		*monitor_routine(void *arg);
void		simulator(t_monitor *monitor, void *(*coder_routine)(void *));
long long	get_closest_deadline(t_monitor *monitor);
void		awake_coders(t_monitor *monitor);
int			is_routine_finished(t_monitor *monitor);
int			check_alert(t_monitor *monitor);
t_coder		*get_next_coder(t_monitor *monitor);
void		*scheduler_routine(void *arg);
int			is_stopped(t_monitor *monitor);
void		set_stopped(t_monitor *monitor);
void		wake_scheduler(t_monitor *monitor);

#endif
