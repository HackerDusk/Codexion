#!/usr/bin/env bash

# ============================================================
# CODEXION — STRICT / HOSTILE / PRE-PUSH TESTER
#
# Objectif :
# - compilation propre
# - parsing agressif
# - memcheck
# - helgrind
# - répétitions
# - burnout
# - arrêt propre
# - contention massive
# - cooldown = 0
# - détection du problème de la moulinette
#
# Exit 0 = très bon signal pour push
# Exit != 0 = problème réel à examiner
# ============================================================

set -u
set -o pipefail

BIN="${1:-./codexion}"
TIMEOUT_SEC=15
TMPDIR_TEST="$(mktemp -d)"

PASS=0
FAIL=0
WARN=0

cleanup()
{
	rm -rf "$TMPDIR_TEST"
}

trap cleanup EXIT

green()
{
	printf "\033[0;32m%s\033[0m\n" "$*"
}

red()
{
	printf "\033[0;31m%s\033[0m\n" "$*"
}

yellow()
{
	printf "\033[1;33m%s\033[0m\n" "$*"
}

pass()
{
	green "✅ PASS - $1"
	PASS=$((PASS + 1))
}

fail()
{
	red "❌ FAIL - $1"
	FAIL=$((FAIL + 1))
}

warn()
{
	yellow "⚠️  WARN - $1"
	WARN=$((WARN + 1))
}

section()
{
	echo
	echo "============================================================"
	echo "$1"
	echo "============================================================"
}

run_timeout()
{
	timeout "$TIMEOUT_SEC" "$@"
}

# ------------------------------------------------------------
# PRECHECK
# ------------------------------------------------------------

section "0 — PRÉCHECK"

if [ ! -x "$BIN" ]; then
	fail "binaire introuvable ou non exécutable: $BIN"
	exit 1
fi

pass "binaire trouvé"

# ============================================================
# SECTION A — BUILD STRICT
# ============================================================

section "A — COMPILATION STRICTE"

if make fclean >/dev/null 2>&1 \
	&& make >/dev/null 2>&1 \
	&& make clean >/dev/null 2>&1
then
	pass "make / make clean"
else
	fail "compilation échouée"
fi

# ============================================================
# SECTION B — PARSING HOSTILE
# ============================================================

section "B — PARSING HOSTILE"

invalid_cases=(
	""
	"1"
	"1 2"
	"1 2 3"
	"1 2 3 4"
	"1 2 3 4 5"
	"1 2 3 4 5 6"
	"1 2 3 4 5 6 7"
	"0 100 100 100 100 1 0 fifo"
	"-1 100 100 100 100 1 0 fifo"
	"3 -1 100 100 100 1 0 fifo"
	"3 100 -1 100 100 1 0 fifo"
	"3 100 100 -1 100 1 0 fifo"
	"3 100 100 100 -1 1 0 fifo"
	"3 100 100 100 100 -1 0 fifo"
	"3 100 100 100 100 1 -1 fifo"
	"2147483648 100 100 100 100 1 0 fifo"
	"3 2147483648 100 100 100 1 0 fifo"
	"3 100 100 100 100 1 0 round_robin"
	"3 100 100 100 100 1 0 FIFO"
	"3.0 100 100 100 100 1 0 fifo"
	"3 100.5 100 100 100 1 0 fifo"
	"abc 100 100 100 100 1 0 fifo"
	"3 abc 100 100 100 1 0 fifo"
	"3 100 100 100 100 abc 0 fifo"
	"3 100 100 100 100 1 abc fifo"
	"3 100 100 100 100 1 0 fifoo"
)

for args in "${invalid_cases[@]}"
do
	if [ -z "$args" ]; then
		timeout 3 "$BIN" >/dev/null 2>&1
	else
		timeout 3 "$BIN" $args >/dev/null 2>&1
	fi

	status=$?

	if [ "$status" -eq 0 ]; then
		fail "argument invalide accepté: [$args]"
	elif [ "$status" -eq 124 ]; then
		fail "hang sur arguments invalides: [$args]"
	else
		pass "rejet propre: [$args]"
	fi
done

# ============================================================
# SECTION C — BURNOUT STRICT
# ============================================================

section "C — BURNOUT ET ARRÊT"

LOG="$TMPDIR_TEST/solo.log"

if run_timeout "$BIN" \
	1 300 100 100 100 1 10 fifo \
	>"$LOG" 2>&1
then
	:
else
	status=$?
	if [ "$status" -eq 124 ]; then
		fail "solo burnout: programme bloqué"
	fi
fi

burn_count=$(grep -c "burned out" "$LOG" || true)

if [ "$burn_count" -eq 1 ]; then
	pass "solo: exactement un burnout"
else
	fail "solo: burnout count=$burn_count"
	cat "$LOG"
fi

# Après burnout, aucune activité fonctionnelle ne devrait continuer
burn_line=$(grep -n "burned out" "$LOG" | head -n1 | cut -d: -f1 || true)

if [ -n "$burn_line" ]; then
	after=$(tail -n "+$((burn_line + 1))" "$LOG" || true)

	if echo "$after" | grep -Eq \
		"is compiling|is debugging|is refactoring|has taken a dongle"
	then
		fail "activité détectée APRÈS burnout"
		echo "$after"
	else
		pass "après burnout: plus d'activité"
	fi
fi

# ============================================================
# SECTION D — COOLDOWN ZERO
# ============================================================

section "D — COOLDOWN = 0"

for mode in fifo edf
do
	LOG="$TMPDIR_TEST/cooldown0_$mode.log"

	if run_timeout "$BIN" \
		5 1000 80 80 80 4 0 "$mode" \
		>"$LOG" 2>&1
	then
		if grep -q "burned out" "$LOG"; then
			fail "cooldown=0 $mode: burnout inattendu"
		else
			pass "cooldown=0 $mode"
		fi
	else
		fail "cooldown=0 $mode: crash ou hang"
	fi
done

# ============================================================
# SECTION E — CONTENTION MAXIMALE
# ============================================================

section "E — CONTENTION MAXIMALE"

stress_cases=(
	"20 2500 5 5 5 20 0 fifo"
	"20 2500 5 5 5 20 0 edf"
	"50 5000 2 2 2 10 0 fifo"
	"50 5000 2 2 2 10 0 edf"
	"100 10000 1 1 1 3 0 fifo"
	"100 10000 1 1 1 3 0 edf"
)

for args in "${stress_cases[@]}"
do
	LOG="$TMPDIR_TEST/stress_$(echo "$args" | tr ' ' '_').log"

	if run_timeout "$BIN" $args >"$LOG" 2>&1
	then
		if grep -q "burned out" "$LOG"; then
			warn "stress burnout: $args"
		else
			pass "stress termine: $args"
		fi
	else
		status=$?
		if [ "$status" -eq 124 ]; then
			fail "DEADLOCK/HANG sous contention: $args"
		else
			fail "CRASH sous contention: $args"
		fi
	fi
done

# ============================================================
# SECTION F — MEMCHECK
# ============================================================

section "F — VALGRIND MEMCHECK"

mem_cases=(
	"1 300 100 100 100 1 10 fifo"
	"5 1500 50 50 50 5 0 fifo"
	"5 1500 50 50 50 5 0 edf"
	"20 3000 5 5 5 10 0 fifo"
)

for args in "${mem_cases[@]}"
do
	LOG="$TMPDIR_TEST/memcheck_$(echo "$args" | tr ' ' '_').log"

	timeout 40 \
	valgrind \
	--tool=memcheck \
	--leak-check=full \
	--show-leak-kinds=all \
	--track-origins=yes \
	--errors-for-leak-kinds=definite,indirect,possible \
	--error-exitcode=42 \
	"$BIN" $args \
	>"$LOG" 2>&1

	status=$?

	if [ "$status" -eq 0 ]; then
		pass "memcheck: $args"
	elif [ "$status" -eq 42 ]; then
		fail "MEMCHECK ERROR: $args"
		grep -A20 -B5 \
			-E "ERROR SUMMARY|Invalid|definitely lost|indirectly lost|possibly lost" \
			"$LOG" | tail -80
	else
		fail "memcheck crash/hang: $args (status=$status)"
	fi
done

# ============================================================
# SECTION G — HELGRIND STRICT
# ============================================================

section "G — HELGRIND STRICT"

helgrind_cases=(
	"4 410 200 200 200 5 10 edf"
	"4 410 200 200 200 5 10 fifo"
	"8 2000 20 20 20 10 0 fifo"
	"8 2000 20 20 20 10 0 edf"
	"20 3000 5 5 5 10 0 fifo"
	"20 3000 5 5 5 10 0 edf"
	"1 300 100 100 100 1 10 fifo"
)

for args in "${helgrind_cases[@]}"
do
	LOG="$TMPDIR_TEST/helgrind_$(echo "$args" | tr ' ' '_').log"

	timeout 60 \
	valgrind \
	--tool=helgrind \
	--history-level=full \
	--error-exitcode=42 \
	"$BIN" $args \
	>"$LOG" 2>&1

	status=$?

	if [ "$status" -eq 0 ]; then
		pass "helgrind: $args"
	elif [ "$status" -eq 42 ]; then
		fail "HELGRIND ERROR: $args"

		grep -A30 -B10 \
			-E "ERROR SUMMARY|Possible data race|conflicting access|lock order|dubious|associated lock" \
			"$LOG" | tail -120
	else
		fail "helgrind crash/hang: $args (status=$status)"
	fi
done

# ============================================================
# SECTION H — REPRODUCTION MOULINETTE FROM HELL
# ============================================================

section "H — REPRODUCTION EXACTE DE LA MOULINETTE"

LOG="$TMPDIR_TEST/moulinette_helgrind.log"

timeout 60 \
valgrind \
--tool=helgrind \
--history-level=full \
--error-exitcode=42 \
"$BIN" 4 410 200 200 200 5 10 edf \
>"$LOG" 2>&1

status=$?

if [ "$status" -eq 0 ]; then
	pass "moulinette Helgrind reproduite: CLEAN"
elif [ "$status" -eq 42 ]; then
	fail "moulinette Helgrind reproduite: ERREUR RÉELLE"

	echo
	echo "--------------- EXTRAIT HELGRIND ---------------"

	grep -A35 -B10 \
	-E "ERROR SUMMARY|dubious|associated lock|Possible data race|conflicting access" \
	"$LOG" | tail -200

	echo "-------------------------------------------------"
else
	fail "moulinette: crash/hang status=$status"
fi

# ============================================================
# SECTION I — FLAKY RACES
# ============================================================

section "I — ANTI-FLAKY / RACES À 1%"

iterations=10
i=1

while [ "$i" -le "$iterations" ]
do
	LOG="$TMPDIR_TEST/flaky_$i.log"

	timeout 40 \
	valgrind \
	--tool=helgrind \
	--history-level=full \
	--error-exitcode=42 \
	"$BIN" 6 2000 20 20 20 10 0 edf \
	>"$LOG" 2>&1

	status=$?

	if [ "$status" -eq 0 ]; then
		pass "flaky helgrind iteration $i/$iterations"
	else
		fail "RACE INTERMITTENTE détectée iteration $i/$iterations"

		grep -A30 -B10 \
			-E "ERROR SUMMARY|dubious|Possible data race|conflicting access" \
			"$LOG" | tail -120

		break
	fi

	i=$((i + 1))
done

# ============================================================
# SECTION J — KILL / STOP
# ============================================================

section "J — ARRÊT PROPRE APRÈS BURNOUT"

for mode in fifo edf
do
	LOG="$TMPDIR_TEST/stop_$mode.log"

	if run_timeout "$BIN" \
		10 50 200 200 200 5 10 "$mode" \
		>"$LOG" 2>&1
	then
		burns=$(grep -c "burned out" "$LOG" || true)

		if [ "$burns" -gt 1 ]; then
			fail "plusieurs burnouts après stop ($mode)"
		else
			pass "arrêt après burnout ($mode)"
		fi
	else
		fail "arrêt après burnout: hang/crash ($mode)"
	fi
done

# ============================================================
# RESULT
# ============================================================

section "RÉSULTAT FINAL"

echo "PASS : $PASS"
echo "FAIL : $FAIL"
echo "WARN : $WARN"

if [ "$FAIL" -ne 0 ]; then
	red
	red "🔥 REFUS DE PUSH."
	red "Il reste au moins un problème détecté."
	exit 1
fi

if [ "$WARN" -ne 0 ]; then
	yellow
	yellow "⚠️ PUSH POSSIBLE MAIS DES SCÉNARIOS ONT PRODUIT DES WARNINGS."
	exit 0
fi

green
green "🟢 PUSH CANDIDATE."
green "Memcheck + Helgrind + contention + burnout + flaky tests : PASS."
exit 0 