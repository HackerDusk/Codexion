#!/bin/bash

# ==============================================================================
# CONFIGURATION
# ==============================================================================
EXEC="./codexion" # Remplace par le nom exact de ton exécutable

# Couleurs pour le terminal
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Vérification de la présence de l'exécutable
if [ ! -f "$EXEC" ]; then
    echo -e "${RED}Erreur : Exécutable $EXEC introuvable. Compile ton projet d'abord.${NC}"
    exit 1
fi

# ==============================================================================
# DÉFINITION DES BATTERIES DE TESTS
# (Adapte les arguments selon le parsing de ton argument_checker.c)
# Format supposé : [nb_codeurs] [mode: FIFO/EDF] [autres_parametres...]
# ==============================================================================

# 1. Tests Humains (Comportement normal attendu)
declare -a TESTS_HUMAINS=(
    "5 FIFO 800 200 200"
    "3 EDF 500 150 150"
    "1 FIFO 1000 500 500"
)

# 2. Tests Hacker (Parsing strict, limites, injections)
declare -a TESTS_HACKER=(
    "-1 FIFO 800 200 200"             # Nombre négatif
    "5 EDF -500 150 150"              # Temps négatif
    "5 FIFO 800 200 200 abc"          # Argument non numérique caché
    "abc EDF 800 200 200"             # Lettres au lieu de chiffres
    "2147483647 FIFO 800 200 200"     # INT_MAX
    "2147483648 EDF 800 200 200"      # INT_MAX + 1 (Overflow)
    ""                                # Zéro argument
    "5"                               # Arguments manquants
)

# 3. Tests Exagérés (Stress test de l'ordonnanceur et des threads)
declare -a TESTS_EXAGERES=(
    "200 FIFO 800 200 200"            # Nombre massif de threads concurrents
    "200 EDF 800 200 200"             # Stress massif sur le tri du tas binaire
)

# 4. Tests Burnout (Rien à faire, famines instantanées, timeouts)
declare -a TESTS_BURNOUT=(
    "0 FIFO 800 200 200"              # Zéro codeur (doit quitter proprement)
    "5 EDF 0 0 0"                     # Temps à zéro (famine ou exécution instantanée)
    "5 FIFO 10 100 100"               # Burnout : meurent/échouent avant d'avoir pu finir
)

# ==============================================================================
# FONCTIONS DE TEST
# ==============================================================================

run_valgrind_memcheck() {
    local args="$1"
    echo -e "${CYAN}▶ Memcheck : $EXEC $args${NC}"
    valgrind --tool=memcheck --leak-check=full --show-leak-kinds=all --errors-for-leak-kinds=all --error-exitcode=42 ./$EXEC $args > /dev/null 2>&1
    if [ $? -eq 42 ]; then
        echo -e "  ${RED}✗ LEAK / ERREUR MÉMOIRE DÉTECTÉE${NC}"
    else
        echo -e "  ${GREEN}✓ Clean${NC}"
    fi
}

run_valgrind_helgrind() {
    local args="$1"
    echo -e "${CYAN}▶ Helgrind : $EXEC $args${NC}"
    valgrind --tool=helgrind --error-exitcode=42 ./$EXEC $args > /dev/null 2>&1
    if [ $? -eq 42 ]; then
        echo -e "  ${RED}✗ DATA RACE / DEADLOCK DÉTECTÉ${NC}"
    else
        echo -e "  ${GREEN}✓ Clean${NC}"
    fi
}

run_test_suite() {
    local suite_name="$1"
    shift
    local arr=("$@")

    echo -e "\n${YELLOW}=== BATTERIE : $suite_name ===${NC}"
    for args in "${arr[@]}"; do
        echo "---------------------------------------------------"
        run_valgrind_memcheck "$args"
        # Helgrind est lourd, on évite de le lancer sur les erreurs de parsing évidentes
        # pour gagner du temps, mais on le force sur les tests extrêmes et burnout.
        if [[ "$suite_name" != "HACKER" ]]; then
            run_valgrind_helgrind "$args"
        fi
    done
}

# ==============================================================================
# EXÉCUTION
# ==============================================================================

echo -e "${YELLOW}Démarrage du protocole de destruction...${NC}"

run_test_suite "HUMAINS" "${TESTS_HUMAINS[@]}"
run_test_suite "HACKER" "${TESTS_HACKER[@]}"
run_test_suite "EXAGÉRÉS" "${TESTS_EXAGERES[@]}"
run_test_suite "BURNOUT" "${TESTS_BURNOUT[@]}"

echo -e "\n${GREEN}Tests terminés.${NC}"