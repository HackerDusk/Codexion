#!/bin/bash

# ==============================================================================
# LE TESTEUR IMPITOYABLE - MULTITHREADING & SCHEDULING (EDF/FIFO)
# ==============================================================================

EXEC="./codexion" # Remplace par le nom de ton exécutable si différent
LOG_DIR="evil_logs"
mkdir -p $LOG_DIR

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m'

echo -e "${RED}>>> DÉBUT DE LA PURGE...${NC}\n"

# Fonction générique de test
run_test() {
    TEST_NAME=$1
    ARGS=$2
    EXPECTED_FAIL=$3

    echo -e "${YELLOW}[TEST] ${TEST_NAME}${NC}"
    echo "Commande : $EXEC $ARGS"
    
    # Execution
    $EXEC $ARGS > /dev/null 2>&1
    RET=$?

    if [ $EXPECTED_FAIL -eq 1 ]; then
        if [ $RET -ne 0 ]; then
            echo -e "${GREEN}✔ Réussite : Le programme a crashé/rejeté proprement (Code $RET).${NC}\n"
        else
            echo -e "${RED}✘ Échec : Le programme a accepté l'inacceptable (Code $RET).${NC}\n"
        fi
    else
        if [ $RET -eq 0 ]; then
            echo -e "${GREEN}✔ Réussite : Le programme a survécu.${NC}\n"
        else
            echo -e "${RED}✘ Échec : Le programme a planté (Code $RET). Segfault ? Deadlock ?${NC}\n"
        fi
    fi
}

# ------------------------------------------------------------------------------
# 1. TESTS DE PARSING (Le cauchemar de l'argument_checker.c)
# On vérifie si tu protèges contre les overflows, les types mixtes et le vide.
# ------------------------------------------------------------------------------
echo -e "${RED}--- PHASE 1 : DESTRUCTION DU PARSING ---${NC}"
run_test "INT_MAX Overflow" "2147483648 10 FIFO" 1
run_test "INT_MIN Underflow" "-2147483648 10 EDF" 1
run_test "Arguments Négatifs" "-5 -10 FIFO" 1
run_test "Types Mixtes" "5a 10b EDF" 1
run_test "Zéro Absolu" "0 0 FIFO" 1
run_test "Pointeurs Nuls virtuels (Rien)" "" 1
run_test "Trop d'arguments" "5 10 FIFO 42 EXTRAS" 1

# ------------------------------------------------------------------------------
# 2. TESTS DE MÉMOIRE EXTRÊMES (Valgrind Memcheck)
# On cherche la fuite vicieuse en cas d'arrêt brutal ou de charge massive.
# ------------------------------------------------------------------------------
echo -e "${RED}--- PHASE 2 : HÉMORRAGIE MÉMOIRE (MEMCHECK) ---${NC}"

echo -e "${YELLOW}[TEST] Fuites sur charge massive et rapide (Heap Stress)${NC}"
valgrind --leak-check=full --show-leak-kinds=all --error-exitcode=42 --log-file=$LOG_DIR/memcheck_heavy.log $EXEC 100 10000 FIFO > /dev/null 2>&1
if [ $? -eq 42 ]; then
    echo -e "${RED}✘ Échec : Fuites détectées ! (Voir $LOG_DIR/memcheck_heavy.log)${NC}\n"
else
    echo -e "${GREEN}✔ Réussite : Aucune fuite sous pression.${NC}\n"
fi

# ------------------------------------------------------------------------------
# 3. TESTS DE CONCURRENCE (Helgrind / Data Races / Deadlocks)
# C'est ici que tes mutexes et variables de condition vont pleurer.
# ------------------------------------------------------------------------------
echo -e "${RED}--- PHASE 3 : L'ENFER DES THREADS (HELGRIND) ---${NC}"

# Test du "Burnout" : Trop de threads, pas assez de ressources
echo -e "${YELLOW}[TEST] Le Burnout (Data Race / Deadlock sur surcharge)${NC}"
# On lance énormément de routines (codeurs) avec un petit tas (heap) pour forcer 
# l'attente sur les condition variables et les conflits de mutex.
valgrind --tool=helgrind --error-exitcode=42 --history-level=approx --log-file=$LOG_DIR/helgrind_burnout.log $EXEC 200 10 EDF > /dev/null 2>&1
if [ $? -eq 42 ]; then
    echo -e "${RED}✘ Échec : Data race ou problème d'ordre de lock détecté ! (Voir $LOG_DIR/helgrind_burnout.log)${NC}\n"
else
    echo -e "${GREEN}✔ Réussite : Synchronisation parfaite sous burnout.${NC}\n"
fi

# Test de famine (Starvation)
echo -e "${YELLOW}[TEST] Famine extrême (FIFO vs EDF)${NC}"
valgrind --tool=helgrind --error-exitcode=42 --log-file=$LOG_DIR/helgrind_starvation.log $EXEC 2 50000 FIFO > /dev/null 2>&1
if [ $? -eq 42 ]; then
    echo -e "${RED}✘ Échec : Tes threads s'emmêlent quand la file d'attente explose. (Voir $LOG_DIR/helgrind_starvation.log)${NC}\n"
else
    echo -e "${GREEN}✔ Réussite : La file d'attente gère la charge sans corruption de données.${NC}\n"
fi

echo -e "${RED}>>> FIN DE LA PURGE. VÉRIFIE LES LOGS DANS LE DOSSIER '$LOG_DIR'.${NC}"