# include "codexion.h"

int	take_a_dongle(t_coder *coder, struct timespec ts)
{
	t_dongle	*first;
	t_dongle	*second;

	if (coder->id % 2 == 0)
	{
		first = coder->left_dongle;
		second = coder->right_dongle;
	}
	else {
		first = coder->right_dongle;
		second = coder->left_dongle;
	}
	pthread_mutex_lock(&first->mutex);
	while(
		(!first->is_free || get_time_ms() < first->available_at)
		&& !is_stopped(coder->monitor))
	{
		if (get_time_ms() < first->available_at)
		{
			ms_to_timespec(first->available_at, &ts);
			pthread_cond_timedwait(
				&first->dongle_cond, &first->mutex, &ts);
		}
		else
			pthread_cond_wait(&first->dongle_cond, &first->mutex);
	}
	if (is_stopped(coder->monitor))
	{
		pthread_mutex_unlock(&first->mutex);
		return (0);
	}
	first->is_free = 0;
	pthread_mutex_lock(&coder->monitor->print_mutex);
	fprintf(stdout, "%lld %d has taken a dongle\n",
		get_time_ms() - coder->monitor->start_time, coder->id);
		pthread_mutex_unlock(&coder->monitor->print_mutex);
		if (coder->monitor->nb_coders == 1)
		{
			pthread_mutex_unlock(&first->mutex);
			while(!is_stopped(coder->monitor))
			usleep(1000);
		return (0);
	}
	pthread_mutex_unlock(&first->mutex);
	pthread_mutex_lock(&second->mutex);
	while(
		(!second->is_free || get_time_ms() < second->available_at)
		&& !is_stopped(coder->monitor))
	{
		if (get_time_ms() < second->available_at)
		{
			ms_to_timespec(second->available_at, &ts);
			pthread_cond_timedwait(
				&second->dongle_cond, &second->mutex, &ts);
		}
		else
			pthread_cond_wait(&second->dongle_cond, &second->mutex);
	}
	if (is_stopped(coder->monitor))
	{
		pthread_mutex_unlock(&second->mutex);
		pthread_mutex_lock(&first->mutex);
		first->available_at = get_time_ms() + first->dongle_cooldown;
		first->is_free = 1;
		pthread_cond_broadcast(&first->dongle_cond);
		pthread_mutex_unlock(&first->mutex);
		return (0);
	}
	second->is_free = 0;
	pthread_mutex_lock(&coder->monitor->print_mutex);
	fprintf(stdout, "%lld %d has taken a dongle\n",
	get_time_ms() - coder->monitor->start_time , coder->id);
	pthread_mutex_unlock(&coder->monitor->print_mutex);
	pthread_mutex_unlock(&second->mutex);
	return (1);
}

void	release_dongles(t_coder *coder)
{
	pthread_mutex_lock(&coder->left_dongle->mutex);
	coder->left_dongle->available_at = get_time_ms() + coder->left_dongle->dongle_cooldown;
	coder->left_dongle->is_free = 1;
	pthread_cond_broadcast(&coder->left_dongle->dongle_cond);
	pthread_mutex_unlock(&coder->left_dongle->mutex);
	
	pthread_mutex_lock(&coder->right_dongle->mutex);
	coder->right_dongle->available_at = get_time_ms() + coder->right_dongle->dongle_cooldown;
	coder->right_dongle->is_free = 1;
	pthread_cond_broadcast(&coder->right_dongle->dongle_cond);
	pthread_mutex_unlock(&coder->right_dongle->mutex);
}

void	*coder_routine(void *arg)
{
	t_coder			*coder;
	struct timespec	ts;
	long long		target;

	coder = (t_coder *)arg;
	while (1)
	{
		pthread_mutex_lock(&coder->monitor->monitor_mutex);
		if (is_stopped(coder->monitor) ||
			coder->compiles_done == coder->number_of_compiles_required
		)
		{
			pthread_mutex_unlock(&coder->monitor->monitor_mutex);
			break;
		}
		pthread_mutex_unlock(&coder->monitor->monitor_mutex);
		pthread_mutex_lock(&coder->monitor->scheduler_mutex);
		if (!coder->is_my_turn)
		{
			coder->request_time = get_time_ms();
			heap_push(coder->monitor->heap, coder);
			pthread_cond_broadcast(&coder->monitor->scheduler_cond);
		}
		while (!coder->is_my_turn && !is_stopped(coder->monitor))
			pthread_cond_wait(&coder->turn_cond, &coder->monitor->scheduler_mutex);
		if (is_stopped(coder->monitor))
		{
			pthread_mutex_unlock(&coder->monitor->scheduler_mutex);
			break;
		}
		coder->is_my_turn = 0;
		pthread_mutex_unlock(&coder->monitor->scheduler_mutex);
		if (!take_a_dongle(coder, ts))
			break;
		pthread_mutex_lock(&coder->monitor->print_mutex);
		if (!is_stopped(coder->monitor))
			fprintf(stdout, "%lld %d is compiling\n",
			get_time_ms() - coder->monitor->start_time, coder->id);
		pthread_mutex_unlock(&coder->monitor->print_mutex);
		
		pthread_mutex_lock(&coder->monitor->monitor_mutex);
		pthread_mutex_lock(&coder->monitor->scheduler_mutex);
		coder->last_compile_start  = get_time_ms();
		pthread_mutex_unlock(&coder->monitor->scheduler_mutex);
		target = coder->last_compile_start + coder->time_to_compile;
		while (get_time_ms() < target && !is_stopped(coder->monitor))
		{
			ms_to_timespec( target, &ts);
			pthread_cond_timedwait(&coder->monitor->monitor_cond, &coder->monitor->monitor_mutex, &ts);
		}
		coder->compiles_done += 1;
		pthread_cond_broadcast(&coder->monitor->monitor_cond);
		pthread_mutex_unlock(&coder->monitor->monitor_mutex);

		pthread_mutex_lock(&coder->monitor->print_mutex);
		if (!is_stopped(coder->monitor))
			fprintf(stdout, "%lld %d is debugging\n",
			get_time_ms() - coder->monitor->start_time, coder->id);
		pthread_mutex_unlock(&coder->monitor->print_mutex);
		release_dongles(coder);
		pthread_mutex_lock(&coder->monitor->monitor_mutex);
		target = get_time_ms() + coder->time_to_debug;
		while (get_time_ms() < target && !is_stopped(coder->monitor))
		{
			ms_to_timespec(target, &ts);
			pthread_cond_timedwait(&coder->monitor->monitor_cond, &coder->monitor->monitor_mutex, &ts);
		}
		pthread_mutex_unlock(&coder->monitor->monitor_mutex);
		pthread_mutex_lock(&coder->monitor->print_mutex);
		if (!is_stopped(coder->monitor))
			fprintf(stdout, "%lld %d is refactoring\n",
			get_time_ms() - coder->monitor->start_time, coder->id);
		pthread_mutex_unlock(&coder->monitor->print_mutex);
		pthread_mutex_lock(&coder->monitor->monitor_mutex);
		target = get_time_ms() + coder->time_to_refactor;
		while (get_time_ms() < target && !is_stopped(coder->monitor))
		{
			ms_to_timespec( target, &ts);
			pthread_cond_timedwait(&coder->monitor->monitor_cond, &coder->monitor->monitor_mutex, &ts);
		}
		pthread_mutex_unlock(&coder->monitor->monitor_mutex);
	}
	return NULL;
}

void	*monitor_routine(void *arg)
{
	t_monitor		*monitor;
	struct timespec	ts;
	long long		closest_deadline;
	int			ret;
	

	monitor = (t_monitor *)arg;
	ret = 0;
	while(1)
	{
		pthread_mutex_lock(&monitor->monitor_mutex);
		closest_deadline = get_closest_deadline(monitor);
		ms_to_timespec(closest_deadline, &ts); 
		ret = pthread_cond_timedwait(&monitor->monitor_cond, &monitor->monitor_mutex, &ts);
		if (ret == ETIMEDOUT)
		{
			if (check_alert(monitor))
			{
				pthread_mutex_unlock(&monitor->monitor_mutex);
				break;
			}
		}
		if (is_routine_finished(monitor))
		{
			set_stopped(monitor);
			pthread_cond_broadcast(&monitor->monitor_cond);
			wake_scheduler(monitor);
			awake_coders(monitor);
			pthread_mutex_unlock(&monitor->monitor_mutex);
			break;
		}
		pthread_mutex_unlock(&monitor->monitor_mutex);
	}
	return (NULL);
}

void	simulator(t_monitor *monitor, void *(*coder_routine)(void *))
{
	int	i;
	
	i = 0;
	monitor->start_time = get_time_ms();
	while (i < monitor->nb_coders)
		monitor->coders[i++].last_compile_start = monitor->start_time;
	i = 0;
	while (i < monitor->nb_coders)
	{
		pthread_create(&monitor->coders[i].thread, NULL, coder_routine,
			&monitor->coders[i]);
			i++;
	}
	pthread_create(&monitor->scheduler_thread, NULL, scheduler_routine,
		monitor);
	pthread_create(&monitor->monitor_thread, NULL, monitor_routine,
		monitor);
	i = 0;
	while (i < monitor->nb_coders)
	{
		pthread_join(monitor->coders[i].thread, NULL);
		i++;
	}
	pthread_join(monitor->monitor_thread, NULL);
	pthread_join(monitor->scheduler_thread, NULL);
	i = 0;
	while (i < monitor->nb_coders)
	{
		pthread_mutex_destroy(&monitor->dongles[i].mutex);
		pthread_cond_destroy(&monitor->dongles[i].dongle_cond);
		pthread_cond_destroy(&monitor->coders[i].turn_cond);
		i++;
	}
	pthread_mutex_destroy(&monitor->monitor_mutex);
	pthread_mutex_destroy(&monitor->print_mutex);
	pthread_cond_destroy(&monitor->monitor_cond);
    pthread_mutex_destroy(&monitor->scheduler_mutex);
    pthread_cond_destroy(&monitor->scheduler_cond);
	pthread_mutex_destroy(&monitor->stop_mutex);
	free(monitor->heap->arr);
	free(monitor->heap);
	free(monitor->coders);
	free(monitor->dongles);
	free(monitor);
}
