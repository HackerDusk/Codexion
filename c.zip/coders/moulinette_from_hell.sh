#!/bin/bash

# Couleurs pour faire mal aux yeux
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}=== DÉMARRAGE DE LA MOULINETTE DE L'ENFER POUR CODEXION ===${NC}\n"

# 1. Test de compilation stricte
echo -e "${YELLOW}[1] Test de compilation (Norme & Makefile)...${NC}"
make fclean > /dev/null
make > /dev/null
if [ ! -f codexion ]; then
    echo -e "${RED}❌ ÉCHEC: Ton Makefile est cassé. Tu ne sais même pas compiler ?${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Compilation OK (pour le moment).${NC}"

# 2. Parsing des arguments (Le test des singes au clavier)
echo -e "\n${YELLOW}[2] Crash-test des arguments impossibles...${NC}"
# Rejet des arguments invalides
./codexion -5 800 200 200 200 7 10 fifo 2>/dev/null
if [ $? -eq 0 ]; then echo -e "${RED}❌ ÉCHEC: Tu as accepté un nombre négatif de codeurs. Sérieusement ?${NC}"; exit 1; fi

./codexion 5 800 200 200 200 7 10 yolo_scheduler 2>/dev/null
if [ $? -eq 0 ]; then echo -e "${RED}❌ ÉCHEC: 'yolo_scheduler' n'est ni 'fifo' ni 'edf'. Tu as lu le sujet ?${NC}"; exit 1; fi
echo -e "${GREEN}✅ Parsing solide. Tu as survécu aux singes.${NC}"

# 3. Test du Solitaire (1 Codeur = Mort inévitable)
echo -e "\n${YELLOW}[3] Test du Solitaire (1 codeur doit mourir de faim avec 1 seul dongle)...${NC}"
# Compiler nécessite 2 dongles
OUTPUT=$(./codexion 1 800 200 200 200 1 10 fifo)
if ! echo "$OUTPUT" | grep -q "burned out"; then
    echo -e "${RED}❌ ÉCHEC: Le codeur 1 a survécu avec un seul dongle... C'est de la magie noire, corrige ça.${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Le codeur 1 est mort dans d'atroces souffrances, comme prévu.${NC}"

# 4. VALGRIND: Le test de la passoire (Memory Leaks)
echo -e "\n${YELLOW}[4] Test Valgrind: Es-tu une passoire à mémoire ?${NC}"
# Aucune fuite mémoire tolérée
valgrind --leak-check=full --error-exitcode=42 ./codexion 4 410 200 200 200 5 10 fifo > /dev/null 2>&1
if [ $? -eq 42 ]; then
    echo -e "${RED}❌ ÉCHEC: Fuites mémoires détectées. Apprends à utiliser free().${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Pas de fuites. Ton heap est propre.${NC}"

# 5. HELGRIND: La guerre des Data Races
echo -e "\n${YELLOW}[5] Test Helgrind: La guerre des Mutexes...${NC}"
# Mutexes requis pour protéger les dongles
valgrind --tool=helgrind --error-exitcode=42 ./codexion 4 410 200 200 200 5 10 edf > /dev/null 2>&1
if [ $? -eq 42 ]; then
    echo -e "${RED}❌ ÉCHEC: Data race détectée ! Tes threads se marchent dessus. Protège tes variables avec des mutexes !${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Helgrind validé. Tes threads se respectent.${NC}"

# 6. Le test de l'Horloger (Précision du Burnout à 10ms)
echo -e "\n${YELLOW}[6] Précision de la faucheuse (tolérance max 10ms)...${NC}"
# Burnout détecté et affiché en moins de 10ms
# Avec 310ms avant burnout, le codeur devrait mourir aux alentours de 310ms.
BURNOUT_LOG=$(./codexion 3 310 200 200 200 1 10 edf | grep "burned out")
BURNOUT_TIME=$(echo $BURNOUT_LOG | awk '{print $1}')

if [ -z "$BURNOUT_TIME" ]; then
    echo -e "${RED}❌ ÉCHEC: Personne n'a burn out, ton programme est bloqué.${NC}"
    exit 1
fi

if [ "$BURNOUT_TIME" -gt 320 ]; then
    echo -e "${RED}❌ ÉCHEC: Burnout à ${BURNOUT_TIME}ms au lieu de ~310ms. Retard de plus de 10ms. Refusé.${NC}"
    exit 1
fi
echo -e "${GREEN}✅ L'horloger est fier. Burnout à ${BURNOUT_TIME}ms.${NC}"

echo -e "\n${GREEN}🔥 FÉLICITATIONS. Ton code est robuste. Tu peux push en paix. 🔥${NC}"